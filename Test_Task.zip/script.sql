CREATE EXTENSION IF NOT EXISTS dblink WITH SCHEMA public;
ALTER EXTENSION dblink SET SCHEMA public;

SELECT public.dblink_connect(
    'comparison_right',
    'host=localhost port=5432 dbname=test_dbbb_right user=postgres password=пароль'
)
WHERE NOT COALESCE(
    'comparison_right' = ANY(public.dblink_get_connections()),
    FALSE
);

WITH differences AS (
    SELECT
        right_schema,
        table_name,
        split_part(columns, ' / ', 1) AS left_column,
        split_part(columns, ' / ', 2) AS right_column,
        split_part(types, ' / ', 1) AS left_type,
        split_part(types, ' / ', 2) AS right_type,
        split_part(nullable, ' / ', 1) AS left_nullable,
        split_part(nullable, ' / ', 2) AS right_nullable
    FROM public.table_diff
),
commands AS (
    SELECT
        1 AS step,
        right_schema,
        table_name,
        'RENAME COLUMN' AS action,
        format(
            'ALTER TABLE %I.%I RENAME COLUMN %I TO %I;',
            right_schema, table_name, right_column, left_column
        ) AS sql_command
    FROM differences
    WHERE left_column <> '—'
      AND right_column <> '—'
      AND left_column <> right_column

    UNION ALL

    SELECT
        2,
        right_schema,
        table_name,
        'ADD COLUMN',
        format(
            'ALTER TABLE %I.%I ADD COLUMN %I %s;',
            right_schema, table_name, left_column, left_type
        )
    FROM differences
    WHERE left_column <> '—'
      AND right_column = '—'

    UNION ALL

    SELECT
        3,
        right_schema,
        table_name,
        'ALTER TYPE',
        CASE
            WHEN left_type = 'date' AND right_type LIKE 'varchar(%'
            THEN format(
                'ALTER TABLE %I.%I ALTER COLUMN %I TYPE %s USING %I::%s;',
                right_schema, table_name, left_column, left_type,
                left_column, left_type
            )
            ELSE format(
                'ALTER TABLE %I.%I ALTER COLUMN %I TYPE %s;',
                right_schema, table_name, left_column, left_type
            )
        END
    FROM differences
    WHERE left_column <> '—'
      AND right_column <> '—'
      AND left_type <> right_type

    UNION ALL

    SELECT
        4,
        right_schema,
        table_name,
        'ALTER NULLABLE',
        CASE
            WHEN left_nullable = 'NOT NULL'
            THEN format(
                'ALTER TABLE %I.%I ALTER COLUMN %I SET NOT NULL;',
                right_schema, table_name, left_column
            )
            ELSE format(
                'ALTER TABLE %I.%I ALTER COLUMN %I DROP NOT NULL;',
                right_schema, table_name, left_column
            )
        END
    FROM differences
    WHERE left_column <> '—'
      AND right_column <> '—'
      AND left_nullable <> right_nullable

    UNION ALL

    SELECT
        5,
        right_schema,
        table_name,
        'NEW COLUMN NOT NULL',
        format(
            'ALTER TABLE %I.%I ALTER COLUMN %I SET NOT NULL;',
            right_schema, table_name, left_column
        )
    FROM differences
    WHERE left_column <> '—'
      AND right_column = '—'
      AND left_nullable = 'NOT NULL'

    UNION ALL

    SELECT
        6,
        right_schema,
        table_name,
        'DROP COLUMN REVIEW',
        format(
            'ALTER TABLE %I.%I DROP COLUMN %I;',
            right_schema, table_name, right_column
        )
    FROM differences
    WHERE left_column = '—'
      AND right_column <> '—'
)
SELECT
    step,
    right_schema,
    table_name,
    action,
    sql_command
FROM commands
ORDER BY right_schema, table_name, step, sql_command;
