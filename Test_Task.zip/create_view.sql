CREATE EXTENSION IF NOT EXISTS dblink WITH SCHEMA public;
ALTER EXTENSION dblink SET SCHEMA public;

SELECT public.dblink_connect(
    'comparison_right',
    'host=localhost port=5432 dbname=test_dbbb_right user=postgres password=пароль'
)
WHERE NOT COALESCE(
    'comparison_right' = ANY(public.dblink_get_connections()),
    FALSE
);

SELECT
    l.table_schema AS left_schema,
    r.table_schema AS right_schema,
    l.table_name
FROM information_schema.tables AS l
INNER JOIN public.dblink(
    'comparison_right',
    $$
    SELECT table_schema::text, table_name::text
    FROM information_schema.tables
    WHERE table_type = 'BASE TABLE'
      AND table_schema IN ('right_saless', 'right_hrr')
    $$
) AS r (table_schema TEXT, table_name TEXT)
    ON l.table_name = r.table_name
WHERE l.table_schema IN ('left_saless', 'left_hrr')
  AND l.table_type = 'BASE TABLE'
ORDER BY l.table_name;

DROP VIEW IF EXISTS public.table_diff;

CREATE VIEW public.table_diff AS
WITH remote_tables AS (
    SELECT *
    FROM public.dblink(
        'comparison_right',
        $$
        SELECT table_schema::text, table_name::text
        FROM information_schema.tables
        WHERE table_type = 'BASE TABLE'
          AND table_schema IN ('right_saless', 'right_hrr')
        $$
    ) AS t (table_schema TEXT, table_name TEXT)
),
remote_columns AS (
    SELECT *
    FROM public.dblink(
        'comparison_right',
        $$
        SELECT
            table_schema::text,
            table_name::text,
            column_name::text,
            data_type::text,
            character_maximum_length::integer,
            numeric_precision::integer,
            numeric_scale::integer,
            is_nullable::text
        FROM information_schema.columns
        WHERE table_schema IN ('right_saless', 'right_hrr')
        $$
    ) AS c (
        table_schema TEXT,
        table_name TEXT,
        column_name TEXT,
        data_type TEXT,
        character_maximum_length INTEGER,
        numeric_precision INTEGER,
        numeric_scale INTEGER,
        is_nullable TEXT
    )
),
matching_tables AS (
    SELECT
        l.table_schema AS left_schema,
        r.table_schema AS right_schema,
        l.table_name
    FROM information_schema.tables AS l
    INNER JOIN remote_tables AS r
        ON l.table_name = r.table_name
    WHERE l.table_schema IN ('left_saless', 'left_hrr')
      AND l.table_type = 'BASE TABLE'
),
left_columns AS (
    SELECT
        m.left_schema,
        m.right_schema,
        m.table_name,
        c.column_name,
        c.data_type,
        c.character_maximum_length,
        c.numeric_precision,
        c.numeric_scale,
        c.is_nullable,
        CASE
            WHEN c.data_type = 'character varying'
                 AND c.character_maximum_length IS NOT NULL
            THEN 'varchar(' || c.character_maximum_length || ')'
            WHEN c.data_type = 'numeric'
                 AND c.numeric_precision IS NOT NULL
            THEN 'numeric(' || c.numeric_precision || ',' || c.numeric_scale || ')'
            ELSE c.data_type
        END AS formatted_type
    FROM matching_tables AS m
    INNER JOIN information_schema.columns AS c
        ON c.table_schema = m.left_schema
       AND c.table_name = m.table_name
),
right_columns AS (
    SELECT
        m.left_schema,
        m.right_schema,
        m.table_name,
        c.column_name,
        c.data_type,
        c.character_maximum_length,
        c.numeric_precision,
        c.numeric_scale,
        c.is_nullable,
        CASE
            WHEN c.data_type = 'character varying'
                 AND c.character_maximum_length IS NOT NULL
            THEN 'varchar(' || c.character_maximum_length || ')'
            WHEN c.data_type = 'numeric'
                 AND c.numeric_precision IS NOT NULL
            THEN 'numeric(' || c.numeric_precision || ',' || c.numeric_scale || ')'
            ELSE c.data_type
        END AS formatted_type
    FROM matching_tables AS m
    INNER JOIN remote_columns AS c
        ON c.table_schema = m.right_schema
       AND c.table_name = m.table_name
)
SELECT
    COALESCE(l.left_schema, r.left_schema) AS left_schema,
    COALESCE(l.right_schema, r.right_schema) AS right_schema,
    COALESCE(l.table_name, r.table_name) AS table_name,
    COALESCE(l.column_name, '—') || ' / ' ||
        COALESCE(r.column_name, '—') AS columns,
    COALESCE(l.formatted_type, '—') || ' / ' ||
        COALESCE(r.formatted_type, '—') AS types,
    (CASE
        WHEN l.is_nullable = 'YES' THEN 'NULL'
        WHEN l.is_nullable = 'NO' THEN 'NOT NULL'
        ELSE '—'
    END) || ' / ' ||
    (CASE
        WHEN r.is_nullable = 'YES' THEN 'NULL'
        WHEN r.is_nullable = 'NO' THEN 'NOT NULL'
        ELSE '—'
    END) AS nullable
FROM left_columns AS l
LEFT JOIN public.column_matches AS m
    ON m.left_schema = l.left_schema
   AND m.right_schema = l.right_schema
   AND m.table_name = l.table_name
   AND m.left_column = l.column_name
FULL OUTER JOIN right_columns AS r
    ON l.left_schema = r.left_schema
   AND l.right_schema = r.right_schema
   AND l.table_name = r.table_name
   AND r.column_name = COALESCE(m.right_column, l.column_name)
WHERE
       l.column_name IS NULL
    OR r.column_name IS NULL
    OR l.column_name IS DISTINCT FROM r.column_name
    OR l.data_type IS DISTINCT FROM r.data_type
    OR l.character_maximum_length IS DISTINCT FROM r.character_maximum_length
    OR l.numeric_precision IS DISTINCT FROM r.numeric_precision
    OR l.numeric_scale IS DISTINCT FROM r.numeric_scale
    OR l.is_nullable IS DISTINCT FROM r.is_nullable;

SELECT * FROM public.table_diff ORDER BY table_name, columns;
