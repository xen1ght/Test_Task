CREATE DATABASE test_dbbb;
CREATE DATABASE test_dbbb_right;

\connect test_dbbb

CREATE SCHEMA left_saless;
CREATE SCHEMA left_hrr;

CREATE TABLE left_saless.orders (
    id INTEGER PRIMARY KEY,
    customer VARCHAR(100) NOT NULL,
    amount NUMERIC(10,2) NOT NULL,
    period VARCHAR(12),
    note TEXT
);

CREATE TABLE left_hrr.employees (
    id INTEGER PRIMARY KEY,
    full_name VARCHAR(120) NOT NULL,
    hired_at DATE
);

CREATE TABLE left_hrr.departments (
    id INTEGER PRIMARY KEY
);

CREATE TABLE public.column_matches (
    left_schema TEXT NOT NULL,
    right_schema TEXT NOT NULL,
    table_name TEXT NOT NULL,
    left_column TEXT NOT NULL,
    right_column TEXT NOT NULL,
    PRIMARY KEY (left_schema, right_schema, table_name, left_column),
    UNIQUE (left_schema, right_schema, table_name, right_column)
);

INSERT INTO public.column_matches (
    left_schema, right_schema, table_name, left_column, right_column
) VALUES (
    'left_saless', 'right_saless', 'orders', 'period', 'reporting_period'
);

CREATE EXTENSION IF NOT EXISTS dblink WITH SCHEMA public;

\connect test_dbbb_right

CREATE SCHEMA right_saless;
CREATE SCHEMA right_hrr;

CREATE TABLE right_saless.orders (
    id INTEGER PRIMARY KEY,
    customer VARCHAR(50),
    amount NUMERIC(12,2),
    reporting_period VARCHAR(12),
    extra_code INTEGER
);

CREATE TABLE right_hrr.employees (
    id INTEGER PRIMARY KEY,
    full_name VARCHAR(120) NOT NULL,
    hired_at VARCHAR(20)
);

CREATE TABLE right_saless.payments (
    id INTEGER PRIMARY KEY
);
